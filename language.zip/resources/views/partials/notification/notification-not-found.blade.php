<div class="list-group-item align-items-center border-bottom">
    <div class="d-flex">
        <div class="mt-1">
            <a href="JavaScript:void(0);"
               class="font-weight-semibold fs-16">Notification Not Found!!
                <span class="clearfix"></span>
                <span class="text-muted font-weight-normal">Notification Isn't Found!!</span></a>
            <span class="clearfix"></span>
        </div>
    </div>
</div>

<script>
    $('.NotificationCount').html('{{ $notificationsCount }}');
</script>
