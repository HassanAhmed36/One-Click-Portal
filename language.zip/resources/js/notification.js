
// Listen for new notifications and play sound if 'Play_Sound' is true

