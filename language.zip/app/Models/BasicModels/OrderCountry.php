<?php

namespace App\Models\BasicModels;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderCountry extends Model
{
    use HasFactory;
    protected $table = "order_countries";
}
